export default {
  data: [
    {
       "pregunta":"Se recomienda acompañar los \ntratamientos con antibióticos con:",
       "respuesta":{
          "uno":"1",
          "dos":"12",
          "tres":"0",
         //  "cuatro":"Hacer ejercicio"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"¿Cuando se toman antibióticos mi cuerpo puede sufrir...?",
       "respuesta":{
          "uno":"3",
          "dos":"93",
          "tres":"12",
         //  "cuatro":"Todas \nlas anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"¿Que es la diarrea del viajero?",
       "respuesta":{
          "uno":"12",
          "dos":"13",
          "tres":"1",
         //  "cuatro":"Todas \nlas anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"¿Que sabor tiene nuestro Prolardii y Procilus D2?",
       "respuesta":{
          "uno":"1",
          "dos":"0",
          "tres":"9",
         //  "cuatro":"Menta y uva"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"Cual es la cepa probiótica de Procilus D2?",
       "respuesta":{
          "uno":"2",
          "dos":"12",
          "tres":"43",
         //  "cuatro":"Ninguna \nde las anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"¿Que cepa probiótica tiene Prolardii?",
       "respuesta":{
          "uno":"43",
          "dos":"27",
          "tres":"7",
         //  "cuatro":"Todas \nlas anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    }, 
    {
       "pregunta":"¿En que presentaciones viene Prolardii?",
       "respuesta":{
          "uno":"23",
          "dos":"87",
          "tres":"2",
         //  "cuatro":"Plegadiza por 20 \ny 40 sobres"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },
    {
       "pregunta":"Los componentes de Procilus D2 son:...",
       "respuesta":{
          "uno":"76",
          "dos":"10",
          "tres":"33",
         //  "cuatro":"Ninguna \nde las anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    },  
    {
       "pregunta":"Los componentes de Prolardii son...",
       "respuesta":{
          "uno":"3",
          "dos":"0",
          "tres":"21",
         //  "cuatro":"Todas \nlas anteriores"
       },
       "correcta":1,
       "loSabias": "Sabias que Tarrito rojo cuenta con 11\nvitaminas que Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit, sed do eiusmod\n tempor incididunt ut labore et dolore\n magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris\n nisi ut aliquip ex ea commodo consequat."
    }
 ]
}